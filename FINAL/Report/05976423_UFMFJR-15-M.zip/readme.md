Project Name

Coursework submission for UFMFJR-15-M - Advanced statistics 22jan_1

Instructions / Contents

- data
	- contains dataset, bibliography files, css
	- will store data output files
- report
	- html - contains rendered html files for each Quarto document
	- main report file as Word docx file
	- optimised models as RDS files
- scripts
	- R - R scripts utilised in Quarto documents
	- Quarto files - 00 - 07, 11, 12
		- 00 - renders complete report - this can take a while (15+ minutes)
		- 01-07 - children of complete report - these can be run individually

Github / Gitlab

- available by email request
	- petter2.lovehagen@live.uwe.ac.uk